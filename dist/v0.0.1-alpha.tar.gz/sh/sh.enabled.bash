#!/bin/sh

SH_ENABLED=(
	'inspire'
	'phphelper'
)